package com.example.game

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var tvResult: TextView
    private lateinit var tvComputerChoice: TextView
    private lateinit var btnRock: AppCompatButton
    private lateinit var btnPaper: AppCompatButton
    private lateinit var btnScissors: AppCompatButton
    private val choices = arrayOf("Rock", "Paper", "Scissors")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        tvResult = findViewById(R.id.tv_result)
        tvComputerChoice = findViewById(R.id.tvComputerChoice)
        btnRock = findViewById(R.id.btn_rock)
        btnPaper = findViewById(R.id.btn_paper)
        btnScissors = findViewById(R.id.btn_scissors)

        btnRock.setOnClickListener { playGame("Rock") }
        btnPaper.setOnClickListener { playGame("Paper") }
        btnScissors.setOnClickListener { playGame("Scissors")}



        }

    private fun playGame(userChoice: String) {
        val computerChoice = choices[Random.nextInt(choices.size)]
        tvComputerChoice.text = "Computer chose: $computerChoice"

        val result = when {
            userChoice == computerChoice -> "It's a draw!"
            userChoice == "Rock" && computerChoice == "Scissors" -> "You Win!"
            userChoice == "Paper" && computerChoice == "Rock" -> "You Win!"
            userChoice == "Scissors" && computerChoice == "Paper" -> "You Win!"
            else -> "You Lose!"
        }

        tvResult.text = result
    }
    }
